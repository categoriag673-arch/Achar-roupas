RoupaFinder - Deploy-ready package for Render (instructions)

O pacote inclui:
- FastAPI backend (app/main.py)
- Detector com YOLOv8 (app/detector.py)
- Scraper Shopee (app/scraper.py)
- Front-end responsivo (app/templates/index.html)
- script download_examples.sh para baixar 2 vídeos de exemplo via yt-dlp
- uploads/ com 2 placeholders: sample_fashion.mp4 e sample_random.mp4

IMPORTANTE:
Este ambiente (onde o pacote foi gerado) não tem acesso à internet, então os dois vídeos de exemplo são placeholders.
Para obter vídeos reais, execute o script `download_examples.sh` localmente (ou no seu servidor/Render) — ele usa yt-dlp.

Como usar localmente:
1) Instale Python 3.10+ e ffmpeg (ffmpeg é usado internamente pelo yt-dlp e para processar vídeos).
2) pip install -r requirements.txt
3) (Opcional) chmod +x download_examples.sh && ./download_examples.sh
4) python -m app.main
5) Abra http://localhost:8000

Como fazer deploy no Render:
1) Crie um novo Web Service no Render, upload do ZIP.
2) Coloque o comando de start: python -m app.main
3) Garanta que o serviço tenha build command: pip install -r requirements.txt
4) Se quiser que os vídeos de exemplo sejam baixados automaticamente, configure um "start" script que execute download_examples.sh antes do start principal.

Sobre os placeholders:
- uploads/sample_fashion.mp4 (placeholder)
- uploads/sample_random.mp4 (placeholder)
Substitua por vídeos reais ou rode download_examples.sh.
