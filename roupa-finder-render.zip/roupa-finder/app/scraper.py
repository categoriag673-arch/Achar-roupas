import requests, urllib.parse

SHOPEE_SEARCH = "https://shopee.com.br/api/v4/search/search_items?keyword={}&limit=6"

def search_shopee(keyword):
    kw = urllib.parse.quote(keyword)
    url = SHOPEE_SEARCH.format(kw)
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Referer": "https://shopee.com.br"
    }
    try:
        r = requests.get(url, headers=headers, timeout=10)
        data = r.json()
    except Exception:
        return []
    products = []
    for item in data.get("items", []):
        p = item.get("item_basic", {})
        if not p:
            continue
        # preço no endpoint vem como inteiro (p['price']) com multiplicador; ajuste conforme retorno
        price = p.get("price")
        try:
            price_val = float(price)/100000
            price_s = f"R$ {price_val:.2f}"
        except Exception:
            price_s = "R$ -"
        products.append({
            "name": p.get("name", "Produto"),
            "price": price_s,
            "image": f"https://cf.shopee.com.br/file/{p.get('image', '')}_tn",
            "url": f"https://shopee.com.br/{p.get('name','').replace(' ', '-')}-i.{p.get('shopid','0')}.{p.get('itemid','0')}"
        })
    return products
