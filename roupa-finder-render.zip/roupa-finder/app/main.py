from fastapi import FastAPI, File, UploadFile, Form, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import shutil, os, uuid, cv2, uvicorn
from app.detector import detect_clothes
from app.scraper import search_shopee

app = FastAPI()

app.mount("/static", StaticFiles(directory="app/templates"), name="static")
templates = Jinja2Templates(directory="app/templates")

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/upload")
async def upload_video(
    file: UploadFile = File(None),
    url: str = Form(None)
):
    vid_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4().hex}.mp4")

    if file:
        with open(vid_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    elif url:
        # tenta baixar via yt-dlp (se estiver disponível no ambiente)
        try:
            import subprocess, shlex
            cmd = f"yt-dlp -o {vid_path} "{url}""
            subprocess.run(shlex.split(cmd), check=True)
        except Exception as e:
            return {"error": f"Falha ao baixar vídeo pelo link: {e}"}
    else:
        return {"error": "Envie um arquivo ou URL"}

    # Extrair 1 frame por segundo
    frames = []
    cap = cv2.VideoCapture(vid_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS)) or 25
    success, frame = cap.read()
    count = 0
    while success:
        if count % fps == 0:
            frames.append(frame)
        success, frame = cap.read()
        count += 1
    cap.release()

    # Detectar roupas
    detected = []
    for f in frames:
        items = detect_clothes(f)
        detected.extend(items)

    # Buscar produtos
    results = []
    for item in set(detected):
        products = search_shopee(item)
        results.append({"item": item, "products": products})

    return {"results": results}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
