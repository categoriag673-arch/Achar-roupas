from ultralytics import YOLO
import cv2

# Carrega um modelo YOLOv8; no deploy você pode trocar por yolov8x.pt para maior precisão
model = YOLO("yolov8n.pt")

# Rótulos que queremos considerar como "peças de roupa"
CLOTHES_LABELS = {
    "person", "backpack", "handbag", "suitcase",
    "tie", "shoe", "umbrella", "hat"
}

def detect_clothes(frame):
    # frame é um numpy array BGR (OpenCV)
    results = model(frame, verbose=False)
    items = []
    for r in results:
        for box in r.boxes:
            label = model.names[int(box.cls)]
            if label in CLOTHES_LABELS:
                items.append(label)
    return items
