#!/usr/bin/env bash
set -e
# Script para baixar 2 vídeos de exemplo usando yt-dlp.
# Substitua as URLs abaixo por URLs públicas de Instagram / TikTok que você tenha permissão para baixar.

OUT_DIR="uploads"
mkdir -p "$OUT_DIR"

# Exemplos (troque pelos que preferir)
FASHION_URL=""  # <- cole aqui a URL do vídeo de moda (Instagram/TikTok)
RANDOM_URL=""   # <- cole aqui a URL de alguém aleatório

if [ -z "$FASHION_URL" ] || [ -z "$RANDOM_URL" ]; then
  echo "Por favor edite este script e coloque FASHION_URL e RANDOM_URL."
  echo "Exemplo de uso: FASHION_URL='https://www.tiktok.com/...' RANDOM_URL='https://www.instagram.com/...' ./download_examples.sh"
  exit 1
fi

echo "Baixando vídeo de moda..."
yt-dlp -o "$OUT_DIR/sample_fashion.%(ext)s" "$FASHION_URL"

echo "Baixando vídeo aleatório..."
yt-dlp -o "$OUT_DIR/sample_random.%(ext)s" "$RANDOM_URL"

echo "Pronto. Verifique uploads/ para os arquivos."
