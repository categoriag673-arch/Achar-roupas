# RoupaFinder (versão leve)
Site que detecta roupas em vídeos enviados e busca produtos parecidos na Shopee.

## Deploy no Render
Build Command: pip install -r requirements.txt
Start Command: python -m app.main

Acesse após o deploy: https://seusite.onrender.com
