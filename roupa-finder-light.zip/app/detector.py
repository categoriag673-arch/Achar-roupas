from ultralytics import YOLO

model = YOLO("yolov8n.pt")
CLOTHES_LABELS = {"person", "backpack", "handbag", "suitcase"}

def detect_clothes(frame):
    results = model(frame, verbose=False)
    items = []
    for r in results:
        for box in r.boxes:
            label = model.names[int(box.cls)]
            if label in CLOTHES_LABELS:
                items.append(label)
    return items
