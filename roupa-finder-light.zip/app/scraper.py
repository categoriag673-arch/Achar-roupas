import requests, urllib.parse

SHOPEE_SEARCH = "https://shopee.com.br/api/v4/search/search_items?keyword={}&limit=6"

def search_shopee(keyword):
    kw = urllib.parse.quote(keyword)
    url = SHOPEE_SEARCH.format(kw)
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://shopee.com.br"}
    r = requests.get(url, headers=headers)
    data = r.json()
    products = []
    for item in data.get("items", []):
        p = item["item_basic"]
        products.append({
            "name": p["name"],
            "price": f"R$ {p['price']/100000:.2f}",
            "image": f"https://cf.shopee.com.br/file/{p['image']}_tn",
            "url": f"https://shopee.com.br/{p['name'].replace(' ', '-')}-i.{p['shopid']}.{p['itemid']}"
        })
    return products
